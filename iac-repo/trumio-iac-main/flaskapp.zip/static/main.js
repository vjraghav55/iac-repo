const form = document.querySelector('form');
const inputBox = document.querySelector('#inputBox');
const answerDiv = document.querySelector('#answer');
const popup_text = `1. **Input Interface:**
    - The GUI comprises a user-friendly input box where users can enter their queries.
    - Upon entering the query, users can initiate the search by clicking the submit button.

2. **Search Results:**
    - The application retrieves the top 5 matches for the query from both the Spanish Constitution and EU law.
    - Each match is presented independently with a clear separation, ensuring a distinct view of the results.

3. **Metadata Tagging:**
    - Each match is associated with metadata tags such as level1, level2, level3, etc.
    - These metadata tags indicate the specific section of the constitution to which the fetched text belongs, facilitating easy navigation for future reference.

4. **Visual Separation:**
    - Matches are visually separated by horizontal lines, providing a clear distinction between individual results.

5. **Coherent Response:**
    - A dedicated section, labeled "ChatGPT Endpoint Response," displays a coherently combined response derived from the top 5 matches.

6. **EU Law Text Access:**
    - Matches from EU law include accessible links under the name tag.
    - Users can hover over or click on these links to open the associated cellar file, providing direct access to the text from EU law.`;

form.addEventListener('submit', (e) => {
    e.preventDefault();
    const userInput = inputBox.value;
    // Process the user input and generate the answer
    processUserInput(userInput);
});


function processUserInput(input) {
    // Write an alert box indicating that results are loading
    //     alert('Results are loading...');

    fetch('/api/openai', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ input: input })
        })
        .then(response => response.json())
        .then(data => {
            // Clear the answerDiv
            answerDiv.innerHTML = '';

            // Create a new paragraph element for the header
            const header = document.createElement('p');
            // make the header bold
            header.style.fontWeight = 'bold';
            header.textContent = 'Top matches:';
            // Append the header to the answerDiv
            answerDiv.appendChild(header);

            // Iterate over the data array
            data.forEach(item => {
                // Iterate over the keys and values of each item
                for (let key in item) {
                    // Create a new paragraph element for each key-value pair
                    const p = document.createElement('p');
                    // if key is 'name': then make a hoverable link over this with the value: https://publications.europa.eu/resource/cellar/{item[key]}
                    if (key === 'name') {
                        const link = document.createElement('a');
                        // remove the extension(.txt) from item[key]
                        const fileName = item[key].replace('.txt', '');
                        link.href = `https://publications.europa.eu/resource/cellar/${fileName}?locale=es`;
                        link.textContent = item[key];
                        p.appendChild(link);
                    } else {
                        p.innerHTML = `<strong>${key}</strong>: ${item[key]}`;
                    }
                    // Append the paragraph to the answerDiv
                    answerDiv.appendChild(p);
                }
                // Create a horizontal line element
                const hr = document.createElement('hr');
                // Append the horizontal line to the answerDiv
                answerDiv.appendChild(hr);
            });

            // Set a timeout to show the popup after a delay
            setTimeout(showpopup, 2000); // Adjust the delay as needed (in milliseconds)
        });
}

function showpopup() {
    const popupWindow = window.open('', '_blank', 'width=600,height=400');
    popupWindow.document.write('<html><head><title>Popup Window</title></head><body>');
    popupWindow.document.write('<pre>' + popup_text + '</pre>');
    popupWindow.document.write('</body></html>');
}