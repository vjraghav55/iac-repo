import os
import time
from flask import Flask, render_template, request, jsonify
from flask import flash
from openai import OpenAI
from pinecone import Pinecone
pc1 = Pinecone(api_key="3c903102-531b-457e-84df-05741429a9b6")
index_spanish_doc = pc1.Index("spanishlaw")
pc2 = Pinecone(api_key="f65cb3a9-0fb8-4137-b3aa-2d6bcf95d597")
index_eu_doc = pc2.Index("eudata")

application = Flask(__name__)
application.config.from_mapping(
    SECRET_KEY='dev',
    DATABASE=os.path.join(application.instance_path, 'flaskr.sqlite'),
)


# a simple page that says hello
@application.route('/')
def hello():
    return render_template('base.html')
os.environ["OPENAI_API_KEY"] = "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"
client_openai = OpenAI()

@application.route('/api/openai', methods=['POST'])
def openai_api():
    data = request.get_json()
    user_input = data['input']

    embedding_query = client_openai.embeddings.create(
        input=[user_input], model="text-embedding-ada-002").data[0].embedding

    results = index_spanish_doc.query(
        vector=embedding_query, top_k=5, include_metadata=True)
    list = [results.matches[i].metadata for i in range(5)]
    # use the unqiue results to generated a combined response with gpt-3.5-turbo-1106
    # design a prompt with the unique results
    prompt = f"Aquí están las coincidencias principales de la Constitución Española para la pregunta {user_input}:\n"
    for i in range(len(list)):
        for key in list[i]:
            prompt += key + ": " + list[i][key] + "\n"
    prompt += "Utilice las mejores coincidencias para responder la pregunta en español:"
    starttime = time.time()
    response = client_openai.chat.completions.create(
        model="gpt-3.5-turbo-1106",
        messages=[
            {"role": "system", "content": 'You are a helpful assistant, you will recieve spansih law artciles related to the users query and the query itself. Please generate a response of the query in Spanish based on the articles recieved.'},
            {"role": "user", "content": prompt}
        ])
    endtime = time.time()
    print("Response Time", endtime - starttime)
    # print(response)
    # print(response['choices'][0]['message']['content'])
    # unique_results.append(response.choices[0].message.content)
    # return jsonify(response.choices[0].text)
    list.append(
        {"ChatGPT end Point response": response.choices[0].message.content})

    results_eu = index_eu_doc.query(
        vector=embedding_query, top_k=5, include_metadata=True)
    # print(results_eu)
    list_eu = [results_eu.matches[i].metadata for i in range(5)]
    list.extend(list_eu)
    return jsonify(list)


if __name__ == '__main__':
    application.run(host="0.0.0.0", port=5000)
